<?php
// DB Params
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'airlines-scrapper');
define('PROXY_URL', 'http://api.scraperapi.com?api_key=d88a98c7f28851d9af258a779cc51fe2&url=');
// App Root
define('APPROOT', dirname(dirname(__FILE__)));
// URL Root
define('URLROOT', 'http://localhost/scrapper-project');
// Site Name
define('SITENAME', 'Airlines Scrapper');
// App Version
define('APPVERSION', '1.0.0');
