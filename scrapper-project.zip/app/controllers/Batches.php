<?php

class Batches extends Controller
{
    public function __construct()
    {
        if (!isLoggedIn()) {
            redirect('users/login');
        };

        $this->batchesModel = $this->loadModel('Batch');
        $this->airlinesModel = $this->loadModel('Airline');
        $this->airlineDetailsModel = $this->loadModel('AirlineDetail');
    }

    public function index()
    {
        $batches = $this->batchesModel->getBatches();

        $this->loadView('batches/index', [
            'active' => 'batches/index',
            'batches' => $batches
        ]);
    }

    public function show($id)
    {
        $batch = $this->batchesModel->getBatchById($id);
        $airlines = $this->airlinesModel->getAirlinesByBatchId($batch->id);

        $this->loadView('batches/show', [
            'active' => 'batches/show',
            'batch' => $batch,
            'airlines' => $airlines
        ]);
    }

    public function store()
    {
        $name = $_POST['name'];

        $this->batchesModel->insert(compact('name'));

        return redirect('/batches/index');
    }

    public function export($batchId)
    {
        $fleetData = $this->airlineDetailsModel->getAllByBatchId($batchId);

        $models = [];

        foreach ($fleetData as $airline) {
            $aircraftType =  $airline->aircraft_type;
            $explodedType = explode(' ', $aircraftType);
            $model = array_pop($explodedType);
            $company = implode(' ', $explodedType);
            if (!isset($models[$company])) $models[$company] = [];
            $models[$company][] = $model;
        }

        $companies = array_keys($models);

        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();

        $spreadsheet->getActiveSheet()->setTitle("Overall");

        foreach ($companies as $key => $company) {
            $spreadsheet->addSheet(new \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet($spreadsheet, $company));
        }

        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, "Xlsx");

        $filename = uniqid(rand(), true) . '.xlsx';

        $writer->save("exports/" . $filename);

        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);

        $downloadLink = URLROOT . '/public/exports/' . $filename;

        flash('import_success', "Data exported successfully! Download at <a href='{$downloadLink}' target='_blank'>Here</a>");
        return redirect('batches/show/' . $batchId);
    }

    public function delete($id)
    {
        $this->batchesModel->delete($id);

        return redirect('/batches/index');
    }
}
