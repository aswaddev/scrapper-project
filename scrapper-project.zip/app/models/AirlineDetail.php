<?php
class AirlineDetail
{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function bulkInsert($airlines, $batchId)
    {
        $values = [];

        foreach ($airlines as $airline) {
            $values[] = '(' . implode(', ', array_values($airline)) . ", $batchId)";
        }

        $values = implode(', ', $values);

        // Prepare query
        $this->db->query("INSERT INTO airline_details (airline, airline_id, aircraft_type, in_service, parked, current_total, future, historic, avg_age, overall_total, batch_id) VALUES $values");

        //Execute
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    // Fetching all airlines
    public function getAllByBatchId($batchId)
    {
        $this->db->query('SELECT * FROM airline_details WHERE batch_id = :batch_id ORDER BY airline');
        $this->db->bind(':batch_id', $batchId);

        $results = $this->db->fetchAll();

        return $results;
    }

    // Fetching a single airline
    public function getAirlineById($id)
    {
        $this->db->query('SELECT * FROM airlines WHERE id = :id');
        $this->db->bind(':id', $id);
        $results = $this->db->fetchOne();
        return $results;
    }
}
