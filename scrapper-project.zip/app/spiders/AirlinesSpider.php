<?php

namespace App\Spiders;

use Generator;
use RoachPHP\Http\Response;
use RoachPHP\Spider\BasicSpider;
use RoachPHP\Downloader\Middleware\RequestDeduplicationMiddleware;
use RoachPHP\Downloader\Middleware\UserAgentMiddleware;

class AirlinesSpider extends BasicSpider
{

    public array $downloaderMiddleware = [
        RequestDeduplicationMiddleware::class,
        [
            UserAgentMiddleware::class,
            ['userAgent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'],
        ],
        ProxyMiddleware::class,
    ];

    // /**
    //  * @var string[]
    //  */
    // public array $startUrls = [
    //     'https://www.planespotters.net/airlines/A'
    // ];

    // public function parse(Response $response): \Generator
    // {
    //     $links = $response
    //         ->filterXPath('//a[contains(@href, "/airline")]')->links();


    //     // foreach ($links as  $link) {
    //     //     yield $this->item([
    //     //         'link' => $link,
    //     //     ]);
    //     // }

    //     yield $this->item([
    //         'links' => $links,
    //     ]);
    // }


    public array $startUrls = [
        'https://www.planespotters.net/airlines/A/1'
    ];

    public function parse(Response $response): Generator
    {
        $links = $response->filter('a[href^="/airline/"]')->links();

        // foreach ($links as $link) {
        //     yield $this->item([
        //         'link' => $link->getUri()
        //     ]);

        //     // if ($link->getUri()) {
        //     //     yield $link->getUri();
        //     // }
        //     // yield ($link->getUri() ? $link->getUri());
        // }

        foreach ($links as $link) {
            yield $this->request('GET', $link->getUri(), 'parseBlogPage');
        }
    }

    public function parseBlogPage(Response $response): Generator
    {
        var_dump($response->getBaseHref());
        var_dump($response->html());
        $title = $response->filter('h1')->text();

        // $publishDate = $response
        //     ->filter('time')
        //     ->attr('datetime');
        // $excerpt = $response
        //     ->filter('.blog-content div > p:first-of-type')
        //     ->text();

        yield $this->item([
            'title' => $title ? $title : ''
        ]);
    }
}
