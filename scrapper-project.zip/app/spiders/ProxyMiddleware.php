<?php

namespace App\Spiders;

use RoachPHP\Http\Request;
use RoachPHP\Downloader\Middleware\RequestMiddlewareInterface;
use RoachPHP\Support\Configurable;

final class ProxyMiddleware implements RequestMiddlewareInterface
{
    use Configurable;

    public function handleRequest(Request $request): Request
    {
        $request->addHeader('origin', $this->option('proxy'));
        $request->addHeader('referer', $this->option('proxy'));

        return $request;
    }

    private function defaultOptions(): array
    {
        return [
            'proxy' => 'http://google.com/',
        ];
    }
}
