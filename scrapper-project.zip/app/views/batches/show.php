<?php require APPROOT . '/views/inc/header.php'; ?>

<a href="<?= URLROOT . '/batches/index' ?>" class="btn btn-secondary mb-2">
    Back
</a>
<section class="jumbotron jumbotron-fluid py-2">
    <div class="container text-center">
        <h1 class="display-4">Airlines - Batch (<?= $data['batch']->name ?>)</h1>
    </div>
</section>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <a href='<?= URLROOT . '/batches/export/' . $data['batch']->id ?>' class="btn btn-success">
            Export
        </a>
    </div>
    <div>
        <a href="<?= URLROOT . '/airlines/links/' . $data['batch']->id  ?>" class="btn btn-outline-secondary">
            Scrap Airlines
        </a>
        <a href="<?= URLROOT . '/airlines/getAirlineDetails/' . $data['batch']->id ?>" class="btn btn-outline-primary mr-2">
            Scrap Fleet Data
        </a>
    </div>
</div>

<?php flash('import_success'); ?>

<div class="table-responsive">
    <table id="dataTable" class="table table-striped table-bordered">
        <thead>
            <tr>
                <!-- <th></th> -->
                <th>#</th>
                <th>Airline</th>
                <th>Link</th>
                <th>Country</th>
                <th>Fleet</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($data['airlines'])) { ?>
                <?php foreach ($data['airlines'] as $key => $airline) { ?>
                    <tr>
                        <!-- <td>
                            <input value='<?= $airline->id ?>' type="checkbox" x-model='selectedAirlines' name="selectedAirlines[]">
                        </td> -->
                        <td><?= $key + 1 ?></td>
                        <td><?= $airline->name ?></td>
                        <td>
                            <a href="<?= $airline->link ?>" target="_blank"><?= $airline->link ?></a>
                        </td>
                        <td><?= $airline->country ?></td>
                        <td><?= $airline->fleet ?></td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr>
                    <td colspan="5">No Data</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php require APPROOT . '/views/inc/footer.php'; ?>