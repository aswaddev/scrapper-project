</main>
<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="<?php echo URLROOT . '/tools/jquery/jquery.min.js'; ?>"></script>
<script src="<?php echo URLROOT . '/tools/bootstrap/js/bootstrap.min.js'; ?>"></script>
<script src="<?php echo URLROOT . '/tools/ckeditor/ckeditor.js'; ?>"></script>
<script src="<?php echo URLROOT . '/js/main.js'; ?>"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4-4.6.0/dt-1.12.1/datatables.min.js"></script>
</body>

</html>