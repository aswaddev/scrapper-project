if (document.getElementById("body")) {
  ClassicEditor.create(document.querySelector("#body"), {
    toolbar: [
      "bold",
      "italic",
      "link",
      "bulletedList",
      "numberedList",
      "blockQuote",
    ],
  })
    .then((editor) => {
      console.log("Editor Initialized");
    })
    .catch((error) => {
      console.error(error);
    });
}

$(document).ready(function () {
  $("#datatable").DataTable({
    lengthChange: true,
    pageLength: 100,
  });
});
